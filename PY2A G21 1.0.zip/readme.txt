Frame can be printed in pla+ or stronger filament
Uses PrintYour2A G17 rails
Front rail insert must be used
Use G21 parts and Gen 5 slide lock spring
Follow G17 assembly instructions