Frame can be printed in pla+ or stronger filament
Uses PrintYour2A G17 rails
Front rail insert must be used
Use G21 trigger bar/shoe, G17 LPK/LB and Gen 5 slide lock spring
Follow G17 assembly instructions